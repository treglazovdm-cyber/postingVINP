"""Local content planner. Python 3.12+, no external dependencies."""
import json
import os
import sqlite3
import threading
import time
import uuid
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

ROOT = Path(__file__).parent
DATA = Path(os.environ.get('DATA_DIR', ROOT / 'data'))
PLATFORMS = {'vk', 'telegram'}
MAX_FILE = 100 * 1024 * 1024


def connect():
    db = sqlite3.connect(DATA / 'planner.sqlite', timeout=15)
    db.row_factory = sqlite3.Row
    return db


def initialize():
    DATA.mkdir(parents=True, exist_ok=True)
    (DATA / 'media').mkdir(exist_ok=True)
    with connect() as db:
        db.executescript('''
        CREATE TABLE IF NOT EXISTS media (
          id TEXT PRIMARY KEY, name TEXT NOT NULL, size INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS posts (
          id TEXT PRIMARY KEY, title TEXT NOT NULL, text TEXT NOT NULL,
          scheduled_at TEXT NOT NULL, platforms TEXT NOT NULL,
          media_id TEXT REFERENCES media(id), status TEXT NOT NULL,
          message TEXT NOT NULL DEFAULT '');
        ''')


def create_post(payload):
    title = str(payload.get('title', '')).strip()
    body = str(payload.get('text', '')).strip()
    platforms = payload.get('platforms', [])
    if not title or len(title) > 200 or len(body) > 10000:
        raise ValueError('Укажите название до 200 символов и текст до 10000 символов.')
    if not isinstance(platforms, list) or not platforms or any(p not in PLATFORMS for p in platforms):
        raise ValueError('Выберите хотя бы одну поддерживаемую площадку.')
    try:
        date = datetime.fromisoformat(payload.get('scheduled_at', '').replace('Z', '+00:00'))
        if date.tzinfo is None or date <= datetime.now(timezone.utc):
            raise ValueError()
    except (ValueError, TypeError):
        raise ValueError('Выберите будущее время с часовым поясом.') from None
    media_id = payload.get('media_id') or None
    with connect() as db:
        if media_id and not db.execute('SELECT 1 FROM media WHERE id=?', (media_id,)).fetchone():
            raise ValueError('Файл не найден.')
        if any(p in platforms for p in ('youtube', 'instagram')) and not media_id:
            raise ValueError('Для YouTube и Instagram выберите медиафайл.')
        post_id = uuid.uuid4().hex
        db.execute('INSERT INTO posts VALUES (?,?,?,?,?,?,?,?)',
                   (post_id, title, body, date.astimezone(timezone.utc).isoformat(),
                    json.dumps(platforms), media_id, 'scheduled', ''))
    return post_id


def process_due(now=None):
    # Never simulate successful delivery. Real adapters require account setup.
    now = now or datetime.now(timezone.utc).isoformat()
    with connect() as db:
        db.execute("UPDATE posts SET status='blocked', message=? WHERE status='scheduled' AND scheduled_at<=?",
                   ('Публикация не отправлена: аккаунты соцсетей ещё не подключены.', now))


def worker():
    while True:
        try:
            process_due()
        except sqlite3.Error:
            print('Scheduler database error', flush=True)
        time.sleep(5)


class Handler(BaseHTTPRequestHandler):
    def reply(self, status, body, content_type='application/json; charset=utf-8'):
        data = json.dumps(body, ensure_ascii=False).encode() if isinstance(body, (dict, list)) else body
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        path = urlsplit(self.path).path
        if path == '/api/health':
            with connect() as db:
                db.execute('SELECT 1 FROM posts LIMIT 1')
            return self.reply(200, {'status': 'ok', 'delivery_enabled': False})
        if path == '/api/posts':
            with connect() as db:
                posts = [dict(r) for r in db.execute('SELECT posts.*, media.name AS media_name FROM posts LEFT JOIN media ON media.id=posts.media_id ORDER BY scheduled_at')]
            for post in posts:
                post['platforms'] = json.loads(post['platforms'])
            return self.reply(200, posts)
        if path == '/api/media':
            with connect() as db:
                return self.reply(200, [dict(r) for r in db.execute('SELECT * FROM media ORDER BY rowid DESC')])
        assets = {'/': ('index.html', 'text/html; charset=utf-8'), '/app.js': ('app.js', 'text/javascript; charset=utf-8'), '/style.css': ('style.css', 'text/css; charset=utf-8')}
        if path in assets:
            name, mime = assets[path]
            return self.reply(200, (ROOT / 'static' / name).read_bytes(), mime)
        self.reply(404, {'error': 'Не найдено'})

    def do_POST(self):
        # Require same-origin browser requests; do not accept cross-site writes.
        origin = self.headers.get('Origin')
        if origin and urlsplit(origin).netloc != self.headers.get('Host'):
            return self.reply(403, {'error': 'Недопустимый источник запроса'})
        try:
            size = int(self.headers.get('Content-Length', '0'))
            if size <= 0 or size > MAX_FILE:
                return self.reply(413, {'error': 'Размер запроса должен быть от 1 байта до 100 МБ.'})
            path = urlsplit(self.path).path
            if path == '/api/media':
                from urllib.parse import unquote
                name = Path(unquote(self.headers.get('X-Filename', 'file'))).name[:200]
                media_id = uuid.uuid4().hex
                target = DATA / 'media' / media_id
                remaining = size
                try:
                    with target.open('xb') as out:
                        while remaining:
                            chunk = self.rfile.read(min(remaining, 1024 * 1024))
                            if not chunk:
                                raise ValueError('Загрузка прервана.')
                            out.write(chunk)
                            remaining -= len(chunk)
                    with connect() as db:
                        db.execute('INSERT INTO media VALUES (?,?,?)', (media_id, name, size))
                except Exception:
                    target.unlink(missing_ok=True)
                    raise
                return self.reply(201, {'id': media_id, 'name': name})
            if size > 64000:
                return self.reply(413, {'error': 'Слишком большой запрос'})
            payload = json.loads(self.rfile.read(size))
            if not isinstance(payload, dict):
                raise ValueError('Ожидается объект JSON.')
            if path == '/api/posts':
                return self.reply(201, {'id': create_post(payload)})
            if path.startswith('/api/cancel/'):
                with connect() as db:
                    result = db.execute("UPDATE posts SET status='cancelled', message='' WHERE id=? AND status IN ('scheduled','blocked')", (path.rsplit('/', 1)[-1],))
                return self.reply(200 if result.rowcount else 404, {'updated': bool(result.rowcount)})
            self.reply(404, {'error': 'Не найдено'})
        except (ValueError, TypeError, AttributeError):
            self.reply(400, {'error': 'Проверьте поля, дату публикации и выбранный файл.'})


if __name__ == '__main__':
    initialize()
    threading.Thread(target=worker, daemon=True).start()
    server = ThreadingHTTPServer((os.environ.get('HOST', '127.0.0.1'), int(os.environ.get('PORT', '8000'))), Handler)
    print('Content planner started', flush=True)
    server.serve_forever()
